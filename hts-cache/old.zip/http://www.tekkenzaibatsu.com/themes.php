
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Themes - Tekken Zaibatsu</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<meta name="title" content="Tekken Zaibatsu - The Ultimate Tekken Resource" />
<meta name="description" content="Themes" />
<meta name="keywords" content="Tekken Tag Tournament 2, Tekken 6, Tekken 6 Bloodline Rebellion, Tekken 5, Tekken 4, Tekken Tag Tournament, Tekken 3, Tekken 2, PlayStation, PlayStation 2, PlayStation 3, PS2, PSX, Arcade Games" />
<meta name="robots" content="index,follow" />
<meta name="revisitafter" content="3 days" />
<meta name="author" content="Castel" />
<meta name="copyright" content="1999-2020 Tekken Zaibatsu" />

<script type="text/javascript" src="/assets/highslide.js"></script>
<script type="text/javascript">
  hs.graphicsDir = '/themes/huntinghawks/highslide/';
</script>
<script type="text/javascript" src="/assets/highslide.config.js" charset="utf-8"></script>
<link rel="stylesheet" type="text/css" href="/themes/huntinghawks/css/highslide.css" />
<link rel="stylesheet" type="text/css" href="/themes/huntinghawks/css/global.css" media="screen" />
<link rel="stylesheet" type="text/css" href="/themes/huntinghawks/css/content.css" media="screen" />

<!--[if IE]>
<link rel="stylesheet" type="text/css" href="/assets/ie.css" />
<![endif]-->
<link rel="stylesheet" type="text/css" href="/assets/print.css" media="print" />
<link rel="shortcut icon" href="/themes/huntinghawks/zaibatsu.ico" />


<!-- Google Analytics -->
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-239563-1', 'auto');
ga('send', 'pageview');
</script>
<!-- End Google Analytics -->

<!-- Outbound Tracking -->
<script>
var trackOutboundLink = function(url) {
   ga('send', 'event', 'outbound', 'click', url, {
     'transport': 'beacon',
     'hitCallback': function(){document.location = url;}
   });
}
</script>
<!-- End Outbound Tracking -->

<script type="text/javascript" src="//cdn.thisiswaldo.com/static/js/5206.js"></script>

</head>

<body>

<div id="header">
  <div id="topnav">
    <ul id="topnav">
      <li><a href="/wiki/Tekken_7">Tekken 7</a></li>
      <li><a href="/tekkentag2">Tekken Tag 2</a></li>
      <li><a href="/tekken6">Tekken 6</a></li>
      <li><a href="/tekken5dr">Tekken 5:DR</a></li>
      <li><a href="/tekken5">Tekken 5</a></li>
      <li><a href="/tekken4">Tekken 4</a></li>
      <li><a href="/tekkentag">Tekken Tag</a></li>
      <li><a href="/tekken3">Tekken 3</a></li>
      <li><a href="/tekken2">Tekken 2</a></li>
      <li><a href="/tekken">Tekken</a></li>
      <li><a name="top">&nbsp;</a></li>
    </ul>
  </div>
  <div id="banner"></div>
</div>

<div id="navigation">
  <div class="content">

      <ul id="nav">
        <li class="index"><a href="/">Index</a>
          <span>
            <a href="/forums/forumdisplay.php?forumid=187" class="subnav">News Archive</a>
            <a href="/themes.php" class="subnav">Site Themes</a>
            <a href="/premium" class="subnav">Premium Zaibatsu</a>
          </span>
        </li>
        <li class="games"><a href="/games">Games</a>
          <span>
            <a href="/wiki/Tekken_7" class="subnav">Tekken 7</a>
            <a href="/tekkentag2" class="subnav">Tekken Tag 2</a>
            <a href="/tekken6" class="subnav">Tekken 6</a>
            <a href="/tekken5dr" class="subnav">Tekken 5:DR</a>
            <a href="/tekken5" class="subnav">Tekken 5</a>
            <a href="/tekken4" class="subnav">Tekken 4</a>
            <a href="/tekkentag" class="subnav">Tekken Tag</a>
            <a href="/tekken3" class="subnav">Tekken 3</a>
            <a href="/tekken2" class="subnav">Tekken 2</a>
            <a href="/tekken" class="subnav">Tekken</a>
            <a href="/tekkenadv" class="subnav">Tekken Advance</a>
          </span>
        </li>
        <li class="forums"><a href="/forums">Forums</a>
          <span>
            <a href="/forums/usercp.php" class="subnav">Control Panel</a>
            <a href="/forums/forumdisplay.php?forumid=1" class="subnav">Zaibatsu Community</a>
            <a href="/forums/forumdisplay.php?forumid=261" class="subnav">Tekken 7</a>
            <a href="/forums/event.php" class="subnav">Tournament Calendar</a>
            <a href="/forums/forumdisplay.php?forumid=26" class="subnav">Match Finder Areas</a>
            <a href="/forums/memberlist.php?what=psn" class="subnav">PSN Players</a>
            <a href="/forums/memberlist.php?what=xbl" class="subnav">XBL Players</a>
            <a href="/forums/search.php" class="subnav">Advanced Search</a>
            <a href="/forums/register.php" class="subnav">Register</a>
          </span>
        </li>
        <li class="gallery"><a href="/gallery">Gallery</a>
          <span>
            <a href="/gallery/index.php#namco" class="subnav">Official NAMCO Art Galleries</a>
            <a href="/gallery/index.php#desktop" class="subnav">Wallpaper Galleries</a>
            <a href="/gallery/index.php#themes" class="subnav">PlayStation3 Themes</a>
            <a href="/gallery/index.php#fanart" class="subnav">Tekken Fan Art</a>
          </span>
        </li>
        <li class="info"><a href="/info">Info</a>
          <span>
            <a href="/info/faq.php" class="subnav">Zaibatsu FAQs</a>
            <a href="/info/contact.php" class="subnav">Contact Staff</a>
            <a href="/info/submitfaq.php" class="subnav">Submitting FAQs</a>
            <a href="/info/submitart.php" class="subnav">Submitting Art</a>
            <a href="/info/sitemap.php" class="subnav">Site Map</a>
            <a href="/info/terms.php" class="subnav">Terms of Use</a>
            <a href="/info/privacy.php" class="subnav">Privacy Policy</a>
          </span>
        </li>
        <li class="wiki"><a href="/wiki">Wiki</a>
          <span>
            <a href="/wiki/Tekken_7" class="subnav">Tekken 7</a>
            <a href="/wiki/Tekken_Tag_Tournament_2" class="subnav">Tekken Tag 2</a>
            <a href="/wiki/Tekken_Tag_Tournament_2_Prologue" class="subnav">Tekken Tag 2 Prologue</a>
            <a href="/wiki/Tekken_6" class="subnav">Tekken 6</a>
          </span>
        </li>
        <li class="legend"><a href="/legend.php" onclick="return hs.htmlExpand(this, { contentId: 'sitelegend', objectType: 'iframe', width: '425', headingText: 'Site Legend', wrapperClassName: 'titlebar' } )">Legend</a></li>
      </ul>

      <div id="search">
        <form action="http://www.tekkenzaibatsu.com/forums/search.php" method="post">
          <input type="hidden" name="forumchoice" value="-1" />
          <input type="hidden" name="searchdate" value="-1" />
          <input type="hidden" name="booleanand" value="yes" />
          <input type="hidden" name="action" value="simplesearch" />
          <input type="text" class="box" name="query" />
	  <button class="go" title="Submit Search">Search</button>
        </form>
      </div>

  </div>
</div>

<div id="content">


  <div id="crumbs">
    <ul>
      <li><a href="/">Home</a></li>
<li>Themes</li>
    </ul>
  </div>
  <div id="adbanner"></div>
<div id="clear"></div>


  <div id="leftcol">

    <h1>Theme Previews</h1>
    
    <fieldset><legend>Hunting Hawks (Default)</legend>
      <div style="text-align: center"><img src="/themes/huntinghawks/preview.png" width="680" height="203" border="0" /></div>
    </fieldset>

    <fieldset><legend>Kazama Sunset</legend>
      <div style="text-align: center"><img src="/themes/kazamasunset/preview.png" width="680" height="203" border="0" /></div>
    </fieldset>

    <fieldset><legend>Silvermist Laboratory</legend>
      <div style="text-align: center"><img src="/themes/silvermist/preview.png" width="680" height="203" border="0" /></div>
    </fieldset>

    <fieldset><legend>Samba Jungle</legend>
      <div style="text-align: center"><img src="/themes/sambajungle/preview.png" width="680" height="203" border="0" /></div>
    </fieldset>

    <fieldset><legend>Devil Within</legend>
      <div style="text-align: center"><img src="/themes/devilwithin/preview.png" width="680" height="203" border="0" /></div>
    </fieldset>

    <fieldset><legend>Ogre Rising</legend>
      <div style="text-align: center"><img src="/themes/ogrerising/preview.png" width="680" height="203" border="0" /></div>
    </fieldset>

    <fieldset><legend>Bloodline Rebellion</legend>
      <div style="text-align: center"><img src="/themes/bloodline/preview.png" width="680" height="203" border="0" /></div>
    </fieldset>

    <fieldset><legend>Arena Americana</legend>
      <div style="text-align: center"><img src="/themes/americana/preview.png" width="680" height="203" border="0" /></div>
    </fieldset>

    <fieldset><legend>Silent Assassin</legend>
      <div style="text-align: center"><img src="/themes/silentassassin/preview.png" width="680" height="203" border="0" /></div>
    </fieldset>

    <fieldset><legend>Mishima Rage</legend>
      <div style="text-align: center"><img src="/themes/mishimarage/preview.png" width="680" height="203" border="0" /></div>
    </fieldset>

    <fieldset><legend>Phoenix Storm</legend>
      <div style="text-align: center"><img src="/themes/phoenixstorm/preview.png" width="680" height="203" border="0" /></div>
    </fieldset>

  </div>

  <div id="rightbar">
    <div id="selectjump">
      <h1>Theme Selector</h1>
      <div class="clearbox">
        <div class="small">Customize your Tekken Zaibatsu browsing experience with one of our site themes. Requires cookies.</div>
        <fieldset class="form">
          <form action="/index.php" method="post">
            <input type="hidden" name="action" value="changestyle" />
            <select name="newstyle" style="width: 240px;">
              <option value="-1">Select a Site Theme</option>
              <option value="1">&raquo; Devil Within</option>
              <option value="2">&raquo; Hunting Hawks</option>
              <option value="3">&raquo; Silent Assassin</option>
              <option value="4">&raquo; Mishima Rage</option>
              <option value="5">&raquo; Bloodline Rebellion</option>
              <option value="6">&raquo; Phoenix Storm</option>
              <option value="7">&raquo; Arena Americana</option>
              <option value="8">&raquo; Ogre Rising</option>
              <option value="9">&raquo; Kazama Sunset</option>
              <option value="10">&raquo; Silvermist Laboratory</option>
              <option value="11">&raquo; Samba Jungle</option>
            </select>
            <button class="btn" title="Go">Go</button>
          </form>
        </fieldset>
      </div>
    </div>
    <div id="adbanner"></div>
  </div>


  <div id="clear"></div>
  
</div>


<div id="footer">
  <div class="content">

    <div id="copyright">
      <span class="rights">Design & Content &copy;1999-2020 Tekken Zaibatsu - All Rights Reserved</span>
      <span class="smilies">Tekken 5 Smilies &copy;2004 Crizl - Tekken 6 Smilies &copy;2010 Spiriax</span>
      <div class="design"><a href="http://www.zaxios.com">Design by Zaxios</a></div>
    </div>

    <div id="links">
      <div class="list">
        <ul>
          <li><a href="/">Home</a></li>
          <li><a href="/wiki/">Tekken Wiki</a></li>
          <li><a href="/forums/forumdisplay.php?forumid=187">News Archive</a></li>
          <li><a href="/themes.php">Site Themes</a></li>
          <li><a href="/premium">Premium Zaibatsu</a></li>
          <br />
          <li><a href="/legend.php" onclick="return hs.htmlExpand(this, { contentId: 'sitelegend', objectType: 'iframe', width: '425', headingText: 'Site Legend', wrapperClassName: 'titlebar' } )">Site Legend</a></li>
        </ul>
      </div>
      <div class="list">
        <ul>
          <li><a href="/games">Games</a></li>
          <li><a href="/wiki/Tekken_7">Tekken 7</a></li>
          <li><a href="/tekkentag2">Tekken Tag 2</a></li>
          <li><a href="/tekken6">Tekken 6</a></li>
          <li><a href="/tekken5dr">Tekken 5:DR</a></li>
          <li><a href="/tekken5">Tekken 5</a></li>
          <li><a href="/tekken4">Tekken 4</a></li>
          <li><a href="/tekkentag">Tekken Tag</a></li>
          <li><a href="/tekken3">Tekken 3</a></li>
          <li><a href="/tekken2">Tekken 2</a></li>
          <li><a href="/tekken">Tekken</a></li>
        </ul>
      </div>
      <div class="list">
        <ul>
          <li><a href="/forums">Forums</a></li>
          <li><a href="/forums/usercp.php">Control Panel</a></li>
          <li><a href="/forums/private.php">Private Messages</a></li>
          <li><a href="/forums/forumdisplay.php?forumid=1">Zaibatsu Community</a></li>
          <li><a href="/forums/forumdisplay.php?forumid=261">Tekken 7</a></li>
          <li><a href="/forums/forumdisplay.php?forumid=26">Match Finder Areas</a></li>
          <li><a href="/forums/event.php">Tournament Calendar</a></li>
          <li><a href="/forums/memberlist.php?what=psn">PSN Player List</a></li>
          <li><a href="/forums/memberlist.php?what=xbl">XBL Player List</a></li>
          <li><a href="/forums/search.php">Advanced Search</a></li>
          <li><a href="/forums/register.php">Register</a></li>
        </ul>
      </div>
      <div class="list">
        <ul>
          <li><a href="/gallery">Gallery</a></li>
          <li><a href="/gallery/index.php#namco">Official NAMCO Art</a></li>
          <li><a href="/gallery/index.php#desktop">Desktop Wallpapers</a></li>
          <li><a href="/gallery/index.php#themes">PlayStation3 Themes</a></li>
          <li><a href="/gallery/index.php#fanart">Tekken Fan Art</a></li>
        </ul>
      </div>
      <div class="list">
        <ul>
          <li><a href="/info">Site Info</a></li>
          <li><a href="/info/faq.php">Zaibatsu FAQs</a></li>
          <li><a href="/info/contact.php">Contact Staff</a></li>
          <li><a href="/info/sitemap.php">Site Map</a></li>
          <li><a href="/info/terms.php">Terms of Use</a></li>
          <li><a href="/info/privacy.php">Privacy Policy</a></li>
        </ul>

        <div id="extra">
          <div><a href="#top">See Ya Up Top!</a></div>
          <div><a href="/webmail.php">Tekken Web Mail</a></div>
        </div>
      </div>
    </div>

    <div id="legal">
      <span class="chibi"></span>
      Tekken Zaibatsu is an unofficial website - Tekken and its characters are a registered trademark and copyright of the NAMCO BANDAI GAMES Inc.
    </div>
    <br />

  </div>
</div>

</body>
</html>

